Joshua Tobler, Samuel Briceno
COP 3402, Fall 2020

To compile and run using the Makefile:
   Make sure all source code and header files are located in the same
   directory as the Makefile, and use the following command:
	make
   To run, use the following command:
	./src_prog <filename> <flags>
   Examples using file "input.txt":
	./src_prog input.txt -l -a -v
	./src_prog input.txt

To compile and run using command line arguments:
   Compile the program using the following command:
	gcc -o compile main.c parser.c lexeme.c codegen.c vm.c
   To run, use the following command:
	./compile <filename> <flags>
   Examples using file "input.txt":
	./compile input.txt -l -a -v
	./compile input.txt


List of compiler flags:
	-l: print the lexeme list and table to the console
	-a: print generated assembly code to the console
	-v: print virtual machine execution trace to the console


Source code uses end-of-file (EOF) markers, so be sure the file is saved
before running the program.