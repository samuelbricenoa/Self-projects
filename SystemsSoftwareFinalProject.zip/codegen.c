// Joshua Tobler, Samuel Briceno
// COP 3402, Fall 2020

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "lexeme.h"
#include "parser.h"
#include "codegen.h"

#define MAX_CODE_LENGTH 500

// function declarations
void emit(int op, int r, int l, int m, code *instruction);
token *getToken2(int *index, char *lexemeList);
int locate(symbol *table, char *ident, int lexlevel, int mark);
void factor2(int *index, symbol *table, char *lexemeList, code *instruction, int regtoendupin, int lexlevel);
void term2(int *index, symbol *table, char *lexemeList, code *instruction, int regtoendupin, int lexlevel);
void expression2(int *index, symbol *table, char *lexemeList, code *instruction, int regtoendupin, int lexlevel);
void condition2(int *index, symbol *table, char *lexemeList, code *instruction, int lexlevel);
void statement2(int *index, symbol *table, char *lexemeList, code *instruction, int lexlevel);
void block2(int *index, symbol *table, char *lexemeList, code *instruction, int lexlevel);
void program2(int *index, symbol *table, char *lexemeList, code *instruction);
int **genCode(symbol *table, char *lexemeList, int flag);

// global variables for OP, R, L, and M indices in array for clarity
#define OP 0
#define R 1
#define L 2
#define M 3

int cx = 0;
int tableSize = 0;
token *currToken;

// function to add instruction to instruction list
void emit(int op, int r, int l, int m, code *instruction)
{
	if (cx > MAX_CODE_LENGTH)
	{
		printf("Error: Too much code!\n");
		exit(1);
	}
	else
	{
		instruction[cx].op = op;
		instruction[cx].r = r;
		instruction[cx].l = l;
		instruction[cx].m = m;
		cx++;
	}
}

// function that returns the next token in the lexeme list
token *getToken2(int *index, char *lexemeList)
{
	int tokenIndex = 0, i;
	token *newToken = calloc(1, sizeof(token));
	newToken->str = calloc(500, sizeof(char));
	char tempChar[20];
	int tempInt[20];

	// if next token is some number, converts it to an integer from char
	if (isdigit(lexemeList[*index]))
	{
		while (lexemeList[*index] != ' ')
		{
			int temp = lexemeList[*index] - '0';
			tempInt[tokenIndex] = temp;
			(*index)++;
			tokenIndex++;
		}

		for (i = 0; i < tokenIndex; i++)
		{
			newToken->num = 10 * newToken->num + tempInt[i];
		}
	}
	else
	{
		// stores identifiers in token struct
		newToken->num = -1;
		int strIndex = 0;
		while (lexemeList[*index] != ' ')
		{
			newToken->str[strIndex] = lexemeList[*index];
			strIndex++;
			tempChar[tokenIndex] = lexemeList[*index];
			(*index)++;
		}
	}

	(*index)++;

	return newToken;
}

// locates a token in the symbol table and returns the index
int locate(symbol *table, char *ident, int lexlevel, int mark)
{
	int index = tableSize;
	int tempLevel = lexlevel;

	// loops through the symbol table from bottom to top to find matching symbols based on the
	// lexlevel and whether or not they are marked
	while (tempLevel >= 0)
	{
		do
		{
			index--;

			// if we find a matching symbol at a greater lexlevel, skips this symbol
			if (strcmp(table[index].name, ident) == 0 && table[index].level > tempLevel)
				index--;
		} while (strcmp(table[index].name, ident) != 0);

		// once we've found a matching symbol, compares the marked status and lexlevel of the symbol
		if (table[index].level == tempLevel)
		{
			if (mark == 0)
			{
				if (table[index].mark == 0)
					return index;
			}
			else
				return index;
		}
		index = tableSize - 1;
		tempLevel--;
	}

	// returns -1 if the desired symbol was not found
	return -1;
}

// function used to calculate factors
void factor2(int *index, symbol *table, char *lexemeList, code *instruction, int regtoendupin, int lexlevel)
{
	// checks if current token is an identifier
	if (currToken->num == identsym)
	{
		int temp;

		// finds an identifier in the symbol table
		currToken = getToken2(index, lexemeList);
		char *tempStr = malloc(sizeof(char) * 500);
		strcpy(tempStr, currToken->str);

		// checks if current identifier is a const or var
		temp = locate(table, tempStr, lexlevel, 0);
		// lit instruction
		if (table[temp].kind == 1)
			emit(1, regtoendupin, 0, table[temp].val, instruction);
		// lod instruction
		if (table[temp].kind == 2)
			emit(3, regtoendupin, lexlevel - table[temp].level, table[temp].addr, instruction);

		currToken = getToken2(index, lexemeList);
	}
	// checks if current token is a number
	else if (currToken->num == numbersym)
	{
		currToken = getToken2(index, lexemeList);
		// lit instruction
		emit(1, regtoendupin, 0, currToken->num, instruction);
		currToken = getToken2(index, lexemeList);
	}
	else
	{
		currToken = getToken2(index, lexemeList);
		expression2(index, table, lexemeList, instruction, regtoendupin, lexlevel);
		currToken = getToken2(index, lexemeList);
	}
}

// function used for terms
void term2(int *index, symbol *table, char *lexemeList, code *instruction, int regtoendupin, int lexlevel)
{
	factor2(index, table, lexemeList, instruction, regtoendupin, lexlevel);
	// loops while dealing with multiplication or division
	while (currToken->num == multsym || currToken->num == slashsym)
	{
		if (currToken->num == multsym)
		{
			currToken = getToken2(index, lexemeList);
			factor2(index, table, lexemeList, instruction, regtoendupin + 1, lexlevel);
			// multiplication instruction
			emit(13, regtoendupin, regtoendupin, regtoendupin + 1, instruction);
		}
		if (currToken->num == slashsym)
		{
			currToken = getToken2(index, lexemeList);
			factor2(index, table, lexemeList, instruction, regtoendupin + 1, lexlevel);
			// division instruction
			emit(14, regtoendupin, regtoendupin, regtoendupin + 1, instruction);
		}
	}
}

// function used for expressions
void expression2(int *index, symbol *table, char *lexemeList, code *instruction, int regtoendupin, int lexlevel)
{
	// checks for leading + or - symbols
	if (currToken->num == plussym)
		currToken = getToken2(index, lexemeList);
	if (currToken->num == minussym)
	{
		currToken = getToken2(index, lexemeList);
		term2(index, table, lexemeList, instruction, regtoendupin, lexlevel);
		// neg instruction
		emit(10, regtoendupin, 0, 0, instruction);

		// loops while handling addition or subtraction
		while (currToken->num == plussym || currToken->num == minussym)
		{
			if (currToken->num == plussym)
			{
				currToken = getToken2(index, lexemeList);
				term2(index, table, lexemeList, instruction, regtoendupin + 1, lexlevel);
				// add instruction
				emit(11, regtoendupin, regtoendupin, regtoendupin + 1, instruction);
			}
			if (currToken->num == minussym)
			{
				currToken = getToken2(index, lexemeList);
				term2(index, table, lexemeList, instruction, regtoendupin + 1, lexlevel);
				// sub instruction
				emit(12, regtoendupin, regtoendupin, regtoendupin + 1, instruction);
			}
		}
		return;
	}

	term2(index, table, lexemeList, instruction, regtoendupin, lexlevel);
	// loops while handling addition or subtraction
	while (currToken->num == plussym || currToken->num == minussym)
	{
		if (currToken->num == plussym)
		{
			currToken = getToken2(index, lexemeList);
			term2(index, table, lexemeList, instruction, regtoendupin + 1, lexlevel);
			// add instruction
			emit(11, regtoendupin, regtoendupin, regtoendupin + 1, instruction);
		}
		if (currToken->num == minussym)
		{
			currToken = getToken2(index, lexemeList);
			term2(index, table, lexemeList, instruction, regtoendupin + 1, lexlevel);
			// sub instruction
			emit(12, regtoendupin, regtoendupin, regtoendupin + 1, instruction);
		}
	}
}

// function for conditions
void condition2(int *index, symbol *table, char *lexemeList, code *instruction, int lexlevel)
{
	if (currToken->num == oddsym)
	{
		currToken = getToken2(index, lexemeList);
		expression2(index, table, lexemeList, instruction, 0, lexlevel);
		// odd instruction
		emit(15, 0, 0, 0, instruction);
	}
	else
	{
		expression2(index, table, lexemeList, instruction, 0, lexlevel);
		if (currToken->num == eqsym)
		{
			currToken = getToken2(index, lexemeList);
			expression2(index, table, lexemeList, instruction, 1, lexlevel);
			// eql instruction
			emit(17, 0, 0, 1, instruction);
		}
		if (currToken->num == neqsym)
		{
			currToken = getToken2(index, lexemeList);
			expression2(index, table, lexemeList, instruction, 1, lexlevel);
			// neq instruction
			emit(18, 0, 0, 1, instruction);
		}
		if (currToken->num == lessym)
		{
			currToken = getToken2(index, lexemeList);
			expression2(index, table, lexemeList, instruction, 1, lexlevel);
			// lss instruction
			emit(19, 0, 0, 1, instruction);
		}
		if (currToken->num == leqsym)
		{
			currToken = getToken2(index, lexemeList);
			expression2(index, table, lexemeList, instruction, 1, lexlevel);
			// leq instruction
			emit(20, 0, 0, 1, instruction);
		}
		if (currToken->num == gtrsym)
		{
			currToken = getToken2(index, lexemeList);
			expression2(index, table, lexemeList, instruction, 1, lexlevel);
			// gtr instruction
			emit(21, 0, 0, 1, instruction);
		}
		if (currToken->num == geqsym)
		{
			currToken = getToken2(index, lexemeList);
			expression2(index, table, lexemeList, instruction, 1, lexlevel);
			// geq instruction
			emit(22, 0, 0, 1, instruction);
		}
	}
}

// function for statements
void statement2(int *index, symbol *table, char *lexemeList, code *instruction, int lexlevel)
{
	int i;
	// checks if current token is an identifier
	if (currToken->num == identsym)
	{
		// finds an identifier in the symbol table
		currToken = getToken2(index, lexemeList);
		char *tempStr = malloc(sizeof(char) * 500);
		strcpy(tempStr, currToken->str);

		int symIndex = locate(table, tempStr, lexlevel, 0);
		for (i = 0; i < 2; i++)
		{
			currToken = getToken2(index, lexemeList);
		}
		expression2(index, table, lexemeList, instruction, 0, lexlevel);
		// sto instruction
		emit(4, 0, lexlevel - table[symIndex].level, table[symIndex].addr, instruction);
	}
	// checks if current token is call
	if (currToken->num == callsym)
	{
		// skips tokens until we have reached the identifier
		currToken = getToken2(index, lexemeList);
		currToken = getToken2(index, lexemeList);

		// finds an identifier in the symbol table
		char *tempStr = malloc(sizeof(char) * 500);
		strcpy(tempStr, currToken->str);

		int symIndex = locate(table, tempStr, lexlevel, 0);
		// call instruction
		emit(5, 0, lexlevel - table[symIndex].level, table[symIndex].addr, instruction);
		currToken = getToken2(index, lexemeList);
	}
	// checks if current token is begin
	if (currToken->num == beginsym)
	{
		currToken = getToken2(index, lexemeList);
		statement2(index, table, lexemeList, instruction, lexlevel);
		// loops while statements end in a semicolon
		while (currToken->num == semicolonsym)
		{
			currToken = getToken2(index, lexemeList);
			statement2(index, table, lexemeList, instruction, lexlevel);
		}
		currToken = getToken2(index, lexemeList);
	}
	// checks if current token is if
	if (currToken->num == ifsym)
	{
		int temp, tempJump;
		currToken = getToken2(index, lexemeList);
		condition2(index, table, lexemeList, instruction, lexlevel);
		temp = cx;
		// jpc instruction
		emit(8, 0, 0, 0, instruction);
		currToken = getToken2(index, lexemeList);
		statement2(index, table, lexemeList, instruction, lexlevel);
		// checks if the current token is else
		if (currToken->num == elsesym)
		{
			currToken = getToken2(index, lexemeList);
			tempJump = cx;
			// jmp instruction
			emit(7, 0, 0, 0, instruction);
			// change the m value of the jpc instruction at index temp to cx
			instruction[temp].m = cx;
			statement2(index, table, lexemeList, instruction, lexlevel);
			// change the m value of the jmp instruction at index tempJump to cx
			instruction[tempJump].m = cx;
		}
		else
		{
			// change the m value of the jpc instruction at index temp to cx
			instruction[temp].m = cx;
		}
	}
	// checks if current token is while
	if (currToken->num == whilesym)
	{
		int tempCondition, tempJump;
		currToken = getToken2(index, lexemeList);
		// saves the code index for the current condition in tempCondition
		tempCondition = cx;
		condition2(index, table, lexemeList, instruction, lexlevel);
		currToken = getToken2(index, lexemeList);
		// saves the code index for the current jump instruction in tempJump
		tempJump = cx;
		// jpc instruction
		emit(8, 0, 0, 0, instruction);
		statement2(index, table, lexemeList, instruction, lexlevel);
		// jmp instruction
		emit(7, 0, 0, tempCondition, instruction);
		// change m value of the jmp instruction and index tempJump to cx
		instruction[tempJump].m = cx;
	}
	// checks if current token is read
	if (currToken->num == readsym)
	{
		int temp;
		for (i = 0; i < 2; i++)
		{
			currToken = getToken2(index, lexemeList);
		}
		// locates current identifier in symbol table
		char *tempStr = malloc(sizeof(char) * 500);
		strcpy(tempStr, currToken->str);

		temp = locate(table, tempStr, lexlevel, 0);

		currToken = getToken2(index, lexemeList);
		// read instruction
		emit(9, 0, 0, 2, instruction);
		// sto instruction
		emit(4, 0, lexlevel - table[temp].level, table[temp].addr, instruction);
	}
	// checks if current token is write
	if (currToken->num == writesym)
	{
		currToken = getToken2(index, lexemeList);
		// calls expression since we can now deal with expressions in write
		expression2(index, table, lexemeList, instruction, 0, lexlevel);
		emit(9, 0, 0, 1, instruction);
	}
}

// function for blocks
void block2(int *index, symbol *table, char *lexemeList, code *instruction, int lexlevel)
{
	int numSymbols = 0;
	int procIndex = 0;
	int numVars = 0, i;
	// checks for constant symbol
	if (currToken->num == constsym)
	{
		do {
			// looks for all constants in code and locates them in the symbol table
			for (i = 0; i < 6; i++)
			{
				currToken = getToken2(index, lexemeList);
				if (i == 1)
				{
					numSymbols++;
					int symIndex = locate(table, currToken->str, lexlevel, 1);
					// unmarks the constant in the symbol table
					table[symIndex].mark = 0;
				}
			}
			// loops for all constants separated by commas
		} while(currToken->num == commasym);

		currToken = getToken2(index, lexemeList);
	}
	// checks for var symbol
	if (currToken->num == varsym)
	{
		do {
			// looks for all vars in the code and locates them in the symbol table
			numVars++;
			for (i = 0; i < 3; i++)
			{
				currToken = getToken2(index, lexemeList);
				if (i == 1)
				{
					numSymbols++;
					int symIndex = locate(table, currToken->str, lexlevel, 1);
					// unmarks the var in the symbol table
					table[symIndex].mark = 0;
				}
			}
			// loops for all vars separated by commas
		} while(currToken->num == commasym);

		currToken = getToken2(index, lexemeList);
	}
	// checks for procedure symbol
	if (currToken->num == procsym)
	{
		do {
			// looks for all procedures in the code and locates them in the symbol table
			for (i = 0; i < 4; i++)
			{
				currToken = getToken2(index, lexemeList);
				if (i == 1)
				{
					numSymbols++;
					int symIndex = locate(table, currToken->str, lexlevel + 1, 1);
					procIndex = symIndex;
					// unmarks the procedure in the symbol table
					table[symIndex].mark = 0;
				}
			}
			// recursively calls block2 at the next lexlevel
			block2(index, table, lexemeList, instruction, lexlevel + 1);
			emit(2, 0, 0, 0, instruction);
			currToken = getToken2(index, lexemeList);
		} while (currToken->num == procsym);
	}
	// loops through the symbol table to update the addr fields of the current procedure
	for (i = 1; i < tableSize; i++)
	{
		if (lexlevel == 0)
		{
			procIndex = 0;
			break;
		}
		else if (table[i].kind == 3 && table[i].level == lexlevel - 1)
		{
			procIndex = i;
			break;
		}
	}
	table[procIndex].addr = cx;
	// inc instruction
	emit(6, 0, 0, 3 + numVars, instruction);
	statement2(index, table, lexemeList, instruction, lexlevel);

	// marks the last 'numSymbols' symbols in the symbol table
	int tempIndex = tableSize - 1;
	int marked = 0;
	while (marked < numSymbols)
	{
		if (table[tempIndex].mark == 0)
		{
			table[tempIndex].mark = 1;
			marked++;
		}
		tempIndex--;
	}
}

// function for the program
void program2(int *index, symbol *table, char *lexemeList, code *instruction)
{
	// emits a jmp instruction for each procedure
	int i, j = 1, k;
	for (i = 0; i < tableSize; i++)
	{
		if (table[i].kind == 3)
		{
			table[i].val = j;
			j++;
			// jmp instruction
			emit(7, 0, 0, 0, instruction);
		}
	}

	currToken = getToken2(index, lexemeList);

	block2(index, table, lexemeList, instruction, 0);

	// updates the jmp instructions to point using the addresses of the procedures
	// from the symbol table
	int tempIndex = 0;
	for (i = 0; instruction[i].op == 7; i++)
	{
		while (table[tempIndex].kind != 3)
			tempIndex++;

		instruction[i].m = table[tempIndex].addr;
		tempIndex++;
	}

	// updates the call instructions to point using the addresses of the procedures
	// from the symbol table
	for (i = 0; i < cx; i++)
	{
		if (instruction[i].op == 5)
		{
			for (k = 0; k < tableSize; k++)
			{
				if (table[k].kind == 3 && table[k].val == instruction[i].m)
				{
					instruction[i].m = table[k].addr;
				}
			}
		}
	}

	// halt instruction
	emit(9, 0, 0, 3, instruction);
}

// function to generate assembly code
int **genCode(symbol *table, char *lexemeList, int flag)
{
	int **finalCode, i, k, index = 0, *ptr;
	code *instruction = malloc(sizeof(code) * MAX_CODE_LENGTH);

	while (table[index].kind != 0)
	{
		tableSize++;
		index++;
	}

	index = 0;

	ptr = &index;

	program2(ptr, table, lexemeList, instruction);

	// converts code instructions from struct to a 2D array
	finalCode = malloc(sizeof(int*) * MAX_CODE_LENGTH);
	for (i = 0; i < cx; i++)
	{
		finalCode[i] = malloc(sizeof(int) * 4);

		finalCode[i][OP] = instruction[i].op;
		finalCode[i][R] = instruction[i].r;
		finalCode[i][L] = instruction[i].l;
		finalCode[i][M] = instruction[i].m;
	}

	// prints out instruction list if '-a' flag is given
	if (flag)
	{
		// print all instructions as assembly code
		printf("\nLine\tOP\tR\tL\tM\n");
		for (k = 0; k < cx; k++)
		{
			printf("%d\t", k);
			// determines which instruction label to print
			switch(finalCode[k][OP])
			{
				case 1:
					printf("LIT\t");
					break;
				case 2:
					printf("RTN\t");
					break;
				case 3:
					printf("LOD\t");
					break;
				case 4:
					printf("STO\t");
					break;
				case 5:
					printf("CAL\t");
					break;
				case 6:
					printf("INC\t");
					break;
				case 7:
					printf("JMP\t");
					break;
				case 8:
					printf("JPC\t");
					break;
				case 9:
					printf("SYS\t");
					break;
				case 10:
					printf("NEG\t");
					break;
				case 11:
					printf("ADD\t");
					break;
				case 12:
					printf("SUB\t");
					break;
				case 13:
					printf("MUL\t");
					break;
				case 14:
					printf("DIV\t");
					break;
				case 15:
					printf("ODD\t");
					break;
				case 16:
					printf("MOD\t");
					break;
				case 17:
					printf("EQL\t");
					break;
				case 18:
					printf("NEQ\t");
					break;
				case 19:
					printf("LSS\t");
					break;
				case 20:
					printf("LEQ\t");
					break;
				case 21:
					printf("GTR\t");
					break;
				case 22:
					printf("GEQ\t");
					break;
			}
			// prints out values of R, L, and M for the current instruction
			printf("%d\t%d\t%d\n", finalCode[k][R], finalCode[k][L], finalCode[k][M]);
		}
	}

	return finalCode;
}
