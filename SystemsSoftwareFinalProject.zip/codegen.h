// Joshua Tobler, Samuel Briceno
// COP 3402, Fall 2020

#ifndef __CODEGEN_H
#define __CODEGEN_H

#include "lexeme.h"
#include "parser.h"

typedef struct code
{
	int op;
	int r;
	int l;
	int m;
} code;

int **genCode(symbol *table, char *lexemeList, int flag);

#endif
