// Joshua Tobler, Samuel Briceno
// COP 3402, Fall 2020

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "lexeme.h"

char *lexAnalyze(char *filename, int flag, int *lexError)
{
	// opens input file
	FILE *f = fopen(filename, "r");
	// arrays for input line of the file, output for lexeme list, and temp array for reserved words
	char input[100], *output, tempOutput[25];
	// counter variables
	int i, j, length;

	// initiate output array for 2000 spaces
	output = calloc(2000, sizeof(char));

	if (flag)
	{
		// headers for lexeme table
		printf("\n\nLexeme Table:\n");
		printf("lexeme\t\ttoken type\n");
	}

	// start of input loop
	while(fgets(input, 100, f))
	{
		length = strlen(input);

		// loop through each character of the input line
		for (i = 0; i < length; i++)
		{
			int error = 0, comment = 0;
			// check if whitespace or control character
			if (iscntrl(input[i]) || isspace(input[i]))
			{
				continue;
			}
			// catches identifier/reserved word
			else if (isalpha(input[i]))
			{
				// temp array to store identifier
				char *temp = calloc(25, sizeof(char));
				int length = 1;
				int reserved = 0;
				j = 0;
				temp[j] = input[i];

				// loops through each character of the current identifier
				while (isalpha(input[i + 1]) || isdigit(input[i + 1]))
				{
					i++;
					j++;
					length++;
					// if over set length, sets error flag and keeps reading until whitespace
					if (length == 12)
					{
						if (*lexError == 0)
							*lexError = 3;
						error = 1;
					}

					temp[j] = input[i];

					// checks to see if identifier is a reserved word if
					// next character is not a letter or digit
					if (!(isalpha(input[i + 1]) || isdigit(input[i + 1])))
					{
						// compares temp array with each reserved word
						if (strcmp(temp, "const") == 0)
						{
							// creates temporary string with reserved word's token type
							sprintf(tempOutput, "%d ", constsym);
							// print token and token type to console
							if (flag)
								printf("const\t\t%d\n", constsym);
							// sets reserved flag
							reserved = 1;
						}
						else if (strcmp(temp, "var") == 0)
						{
							sprintf(tempOutput, "%d ", varsym);
							if (flag)
								printf("var\t\t%d\n", varsym);
							reserved = 1;
						}
						else if (strcmp(temp, "procedure") == 0)
						{
							sprintf(tempOutput, "%d ", procsym);
							if (flag)
								printf("procedure\t%d\n", procsym);
							reserved = 1;
						}
						else if (strcmp(temp, "call") == 0)
						{
							sprintf(tempOutput, "%d ", callsym);
							if (flag)
								printf("call\t\t%d\n", callsym);
							reserved = 1;
						}
						else if (strcmp(temp, "begin") == 0)
						{
							sprintf(tempOutput, "%d ", beginsym);
							if (flag)
								printf("begin\t\t%d\n", beginsym);
							reserved = 1;
						}
						else if (strcmp(temp, "end") == 0)
						{
							sprintf(tempOutput, "%d ", endsym);
							if (flag)
								printf("end\t\t%d\n", endsym);
							reserved = 1;
						}
						else if (strcmp(temp, "if") == 0)
						{
							sprintf(tempOutput, "%d ", ifsym);
							if (flag)
								printf("if\t\t%d\n", ifsym);
							reserved = 1;
						}
						else if (strcmp(temp, "then") == 0)
						{
							sprintf(tempOutput, "%d ", thensym);
							if (flag)
								printf("then\t\t%d\n", thensym);
							reserved = 1;
						}
						else if (strcmp(temp, "else") == 0)
						{
							sprintf(tempOutput, "%d ", elsesym);
							if (flag)
								printf("else\t\t%d\n", elsesym);
							reserved = 1;
						}
						else if (strcmp(temp, "while") == 0)
						{
							sprintf(tempOutput, "%d ", whilesym);
							if (flag)
								printf("while\t\t%d\n", whilesym);
							reserved = 1;
						}
						else if (strcmp(temp, "do") == 0)
						{
							sprintf(tempOutput, "%d ", dosym);
							if (flag)
								printf("do\t\t%d\n", dosym);
							reserved = 1;
						}
						else if (strcmp(temp, "read") == 0)
						{
							sprintf(tempOutput, "%d ", readsym);
							if (flag)
								printf("read\t\t%d\n", readsym);
							reserved = 1;
						}
						else if (strcmp(temp, "write") == 0)
						{
							sprintf(tempOutput, "%d ", writesym);
							if (flag)
								printf("write\t\t%d\n", writesym);
							reserved = 1;
						}
						else if (strcmp(temp, "odd") == 0)
						{
							sprintf(tempOutput, "%d ", oddsym);
							if (flag)
								printf("odd\t\t%d\n", oddsym);
							reserved = 1;
						}
					}
				}
				// if not a reserved word, prints out the identifier
				if (error)
				{
					if (flag)
						printf("%s\tError: Name too long.\n", temp);
				}
				else if (!reserved)
				{
					sprintf(tempOutput, "%d %s ", identsym, temp);
					if (flag)
						printf("%s\t\t%d\n", temp, identsym);
				}

				free(temp);
			}
			// catches number
			else if(isdigit(input[i]))
			{
				char *temp = calloc(25, sizeof(char));
				int length = 1;
				j = 0;
				temp[j] = input[i];

				// checks to make sure next character is a digit
				while (isdigit(input[i + 1]) || (isalpha(input[i + 1]) && length >= 6))
				{
					i++;
					j++;
					length++;
					// if over set length, sets error flag and keeps reading until whitespace
					if (length == 6)
					{
						if (*lexError == 0)
							*lexError = 2;
						error = 1;
					}

					temp[j] = input[i];
				}
				// if an error occurred, print out the cause of the error and the type of error
				// takes precedence of invalid identifier error if found
				if (error)
				{
					if (flag)
					{
						if (length < 10)
							printf("%s\t\tError: Number too long.\n", temp);
						else
							printf("%s\tError: Number too long.\n", temp);
					}
					continue;
				}

				// invalid identifier, sets error flag and continues reading until whitespace
				// or control character
				if (isalpha(input[i + 1]))
				{
					while (!(iscntrl(input[i + 1]) || isspace(input[i + 1])))
					{
						i++;
						j++;
						temp[j] = input[i];
						continue;
					}
					error = 1;
					if (*lexError == 0)
						*lexError = 1;
					if (flag)
						printf("%s\t\tError: Invalid identifier.\n", temp);
				}
				else
				{
					sprintf(tempOutput, "%d %s ", numbersym, temp);
					if (flag)
						printf("%s\t\t%d\n", temp, numbersym);
				}
				free(temp);
			}
			// compares input to each valid symbol
			else if (input[i] == '+')
			{
				sprintf(tempOutput, "%d ", plussym);
				if (flag)
					printf("+\t\t%d\n", plussym);
			}
			else if (input[i] == '-')
			{
				sprintf(tempOutput, "%d ", minussym);
				if (flag)
					printf("-\t\t%d\n", minussym);
			}
			else if (input[i] == '*')
			{
				sprintf(tempOutput, "%d ", multsym);
				if (flag)
					printf("*\t\t%d\n", multsym);
			}
			else if (input[i] == '=')
			{
				sprintf(tempOutput, "%d ", eqsym);
				if (flag)
					printf("=\t\t%d\n", eqsym);
			}
			else if (input[i] == '(')
			{
				sprintf(tempOutput, "%d ", lparentsym);
				if (flag)
					printf("(\t\t%d\n", lparentsym);
			}
			else if (input[i] == ')')
			{
				sprintf(tempOutput, "%d ", rparentsym);
				if (flag)
					printf(")\t\t%d\n", rparentsym);
			}
			else if (input[i] == ',')
			{
				sprintf(tempOutput, "%d ", commasym);
				if (flag)
					printf(",\t\t%d\n", commasym);
			}
			else if (input[i] == ';')
			{
				sprintf(tempOutput, "%d ", semicolonsym);
				if (flag)
					printf(";\t\t%d\n", semicolonsym);
			}
			else if (input[i] == '.')
			{
				sprintf(tempOutput, "%d ", periodsym);
				if (flag)
					printf(".\t\t%d\n", periodsym);
			}
			else if (input[i] == '<')
			{
				if (input[i + 1] == '>')
				{
					i++;
					sprintf(tempOutput, "%d ", neqsym);
					if (flag)
						printf("<>\t\t%d\n", neqsym);
				}
				else if (input[i + 1] == '=')
				{
					i++;
					sprintf(tempOutput, "%d ", leqsym);
					if (flag)
						printf("<=\t\t%d\n", leqsym);
				}
				else
				{
					sprintf(tempOutput, "%d ", lessym);
					if (flag)
						printf("<\t\t%d\n", lessym);
				}
			}
			else if (input[i] == '>')
			{
				if (input[i + 1] == '=')
				{
					i++;
					sprintf(tempOutput, "%d ", geqsym);
					if (flag)
						printf(">=\t\t%d\n", geqsym);
				}
				else
				{
					sprintf(tempOutput, "%d ", gtrsym);
					if (flag)
						printf(">\t\t%d\n", gtrsym);
				}
			}
			else if (input[i] == ':')
			{
				if (input[i + 1] == '=')
				{
					i++;
					sprintf(tempOutput, "%d ", becomessym);
					if (flag)
						printf(":=\t\t%d\n", becomessym);
				}
				else
				{
					// invalid symbol error
					if (flag)
						printf("Invalid symbols.\n");
					error = 1;
				}
			}
			else if (input[i] == '/')
			{
				// catches comment and ignores those characters
				if (input[i + 1] == '*')
				{
					i++;
					while (!(input[i + 1] == '*' && input[i + 2] == '/'))
					{
						i++;
					}
					i += 2;
					// sets comment flag
					comment = 1;
				}
				// if no comment is found, accepts '/' symbol
				else
				{
					sprintf(tempOutput, "%d ", slashsym);
					if (flag)
						printf("/\t\t%d\n", slashsym);
				}
			}
			// if we have an invalid symbol, throws an invalid symbol error and sets the error flag
			else
			{
				if (flag)
					printf("%c\t\tError: Invalid symbol.\n", input[i]);
				error = 1;
				if (*lexError == 0)
					*lexError = 4;
			}
			// adds tempOutput to our lexeme list if error and comment flags are not set
			if (!error && !comment)
				strcat(output, tempOutput);
		}
	}
	if (flag)
	{
		printf("\nLexeme List:\n");
		printf("%s\n", output);
	}

	strcat(output, " ");

	return output;
}
