// Joshua Tobler, Samuel Briceno
// COP 3402, Fall 2020

#ifndef __LEXEME_H
#define __LEXEME_H

typedef enum
{
	nulsym = 1, identsym, numbersym, plussym, minussym,
	multsym, slashsym, oddsym, eqsym, neqsym, lessym, leqsym,
	gtrsym, geqsym, lparentsym, rparentsym, commasym, semicolonsym,
	periodsym, becomessym, beginsym, endsym, ifsym, thensym,
	whilesym, dosym, callsym, constsym, varsym, procsym, writesym,
	readsym, elsesym
} token_type;

char *lexAnalyze(char *inputFile, int flag, int *lexError);

#endif
