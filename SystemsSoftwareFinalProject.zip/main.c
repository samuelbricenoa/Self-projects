// Joshua Tobler, Samuel Briceno
// COP 3402, Fall 2020

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lexeme.h"
#include "parser.h"
#include "codegen.h"
#include "vm.h"

int main(int argc, char **argv)
{
	// if no filename is given, throws an error and displays correct syntax
	if (argc < 2)
	{
		printf("Error: Improper syntax.\n");
		printf("Proper syntax: %s <filename> <flags>\n", argv[0]);
		printf("Valid compiler flags:\n");
		printf("\t-l: Includes output of lexemes/tokens\n");
		printf("\t-a: Includes generated assembly code output\n");
		printf("\t-v: Includes virtual machine output\n");
		printf("Example: %s input.txt -l -a -v\n", argv[0]);
		exit(1);
	}

	// local variable declarations for driver
	int i = 0, j, lexError = 0, *ptr;
	int lflag = 0, aflag = 0, vflag = 0;
	char *filename = argv[1];
	FILE *f = fopen(filename, "r");
	if (f == NULL)
	{
		printf("Error: Failed to open %s\n", filename);
		exit(1);
	}
	char *input = malloc(sizeof(char) * 500);
	char temp = fgetc(f);

	ptr = &lexError;

	// loops through the input file to store the supplied code in a string
	while (temp != EOF)
	{
		input[i++] = temp;
		temp = fgetc(f);
	}
	input[i] = '\0';

	// checks for any compiler flags supplied
	for (j = 2; j < argc; j++)
	{
		if (strcmp(argv[j], "-l") == 0)
			lflag = 1;
		else if (strcmp(argv[j], "-a") == 0)
			aflag = 1;
		else if (strcmp(argv[j], "-v") == 0)
			vflag = 1;
	}

	// prints out the source program supplied
	printf("Source Program:\n");
	printf("%s", input);

	// passes the source code through the lexical analyzer
	char *lexemeList = lexAnalyze(filename, lflag, ptr);
	// passes the lexeme list through the parser
	symbol *table = parse(lexemeList, lexError);
	if (table == NULL)
		return 0;
	// passes the symbol table and lexeme list through the code generator
	int **code = genCode(table, lexemeList, aflag);
	// executes generated assembly code on the virtual machine
	virtualMachine(code, vflag);

	return 0;
}
