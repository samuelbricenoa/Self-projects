// Joshua Tobler, Samuel Briceno
// COP 3402, Fall 2020

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "parser.h"
#include "lexeme.h"

#define MAX_SYMBOL_TABLE_SIZE 500

// global variables
int size = 0, error = 0, thenFlag = 0;

// function declarations
int contains(symbol *table, char *ident, int topDown, int type);
symbol add(symbol *table, int kind, char *name, int num, int level, int addr, int mark);
int constDeclaration(int *index, symbol *table, char *lexemeList, int lexlevel);
int varDeclaration(int *index, symbol *table, char *lexemeList, int lexlevel);
int procedureDeclaration(int *index, symbol *table, char *lexemeList, int lexlevel);
void condition(int *index, symbol *table, char *lexemeList, int lexlevel);
void factor(int *index, symbol *table, char *lexemeList, int lexlevel);
void term(int *index, symbol *table, char *lexemeList, int lexlevel);
void expression(int *index, symbol *table, char *lexemeList, int lexlevel);
void statement(int *index, symbol *table, char *lexemeList, int lexlevel);
void block(int *index, symbol *table, char *lexemeList, int lexlevel);
void program(int *index, symbol *table, char *lexemeList);
token *getToken(int *index, char *lexemeList);

// checks to see if our symbol table contains an identifier
// if so, returns the index, if not, returns -1
int contains(symbol *table, char *ident, int topDown, int type)
{
	int index;
	// checks if we are searching the symbol table from the top-down or from the bottom-up
	if (topDown == 0)
	{
		// loops through each index in the symbol table and returns the matching index
		for (index = 0; index < size; index++)
		{
			if (strcmp(table[index].name, ident) == 0)
				return index;
		}
	}
	else
	{
		for (index = size - 1; index >= 0; index--)
		{
			// skips all marked symbols in the table
			if (table[index].mark != 0)
				continue;

			// checks for a matching symbol based on the type parameter passed
			if (type == 2)
				if (strcmp(table[index].name, ident) == 0 && (table[index].kind == 1 || table[index].kind == 2))
					return index;
			if (type == 3)
				if (strcmp(table[index].name, ident) == 0 && table[index].kind == 3)
					return index;
		}
	}

	// returns -1 if the symbol is not found
	return -1;
}

token *currToken;

// adds a symbol to our symbol table
symbol add(symbol *table, int kind, char *name, int num, int level, int addr, int mark)
{
	symbol temp;

	temp.kind = kind;
	strcpy(temp.name, name);
	temp.val = num;
	temp.level = level;
	temp.addr = addr;
	temp.mark = mark;

	return temp;
}

// function for const declarations in beginning of code
int constDeclaration(int *index, symbol *table, char *lexemeList, int lexlevel)
{
	int numConsts = 0;
	// reads in constants separated by commas
	do {
		currToken = getToken(index, lexemeList);
		// makes sure an identifier follows const
		if (currToken->num != identsym)
		{
			error = 1;
			printf("Error: Expected identifier after const.\n");
			exit(1);
		}

		// looks for an identifier in the symbol table
		char *tempStr = malloc(sizeof(char) * 500);
		strcpy(tempStr, getToken(index, lexemeList)->str);
		int tempIndex = contains(table, tempStr, 0, 0);
		if (tempIndex != -1 && table[tempIndex].mark == 0 && table[tempIndex].level == lexlevel)
		{
			error = 1;
			printf("Error: Duplicate identifier.\n");
			exit(1);
		}

		// makes sure each identifier is followed by an equals sign
		currToken = getToken(index, lexemeList);
		if (currToken->num != eqsym)
		{
			error = 1;
			printf("Error: const identifier must be followed by =.\n");
			exit(1);
		}

		// makes sure each constant is assigned to a numerical value
		currToken = getToken(index, lexemeList);
		if (currToken->num != numbersym)
		{
			error = 1;
			printf("Error: = must be followed by a number.\n");
			exit(1);
		}

		int num = getToken(index, lexemeList)->num;
		// add to symbol table with kind 1 and then increment the size
		table[size] = add(table, 1, tempStr, num, lexlevel, 0, 0);
		size++;
		currToken = getToken(index, lexemeList);

		numConsts++;
	} while(currToken->num == commasym);
	// throws an error if const declarations are not followed by a semicolon
	if (currToken->num != semicolonsym)
	{
		error = 1;
		printf("Error: Semicolon or comma missing.\n");
		exit(1);
	}

	currToken = getToken(index, lexemeList);

	return numConsts;
}

// function for var declarations in beginning of code
int varDeclaration(int *index, symbol *table, char *lexemeList, int lexlevel)
{
	// keeps track of the number of variables
	int numVars = 0;
	do {
		numVars++;
		currToken = getToken(index, lexemeList);
		// makes sure var declarations are followed by an identifier
		if (currToken->num != identsym)
		{
			error = 1;
			printf("Error: Expected identifier after var.\n");
			exit(1);
		}

		// makes sure we do not contain duplicate identifiers
		char *tempStr = malloc(sizeof(char) * 500);
		strcpy(tempStr, getToken(index, lexemeList)->str);
		int tempIndex = contains(table, tempStr, 0, 0);
		if (tempIndex != -1 && table[tempIndex].mark == 0 && table[tempIndex].level == lexlevel)
		{
			error = 1;
			printf("Error: Duplicate identifier.\n");
			exit(1);
		}

		// adds the var to the symbol table with kind 2 and increments size
		table[size] = add(table, 2, tempStr, 0, lexlevel, numVars + 2, 0);
		size++;

		currToken = getToken(index, lexemeList);
	} while(currToken->num == commasym);
	// throws an error if const declarations are not followed by a semicolon
	if (currToken->num != semicolonsym)
	{
		error = 1;
		printf("Error: Semicolon or comma missing.\n");
		exit(1);
	}

	currToken = getToken(index, lexemeList);

	return numVars;
}

int procedureDeclaration(int *index, symbol *table, char *lexemeList, int lexlevel)
{
	int numProcedures = 0;
	// reads in the next procedure
	if (currToken->num == procsym)
	{
		do {
			currToken = getToken(index, lexemeList);
			// makes sure an identifier follows procedure
			if (currToken->num != identsym)
			{
				error = 1;
				printf("Error: Expected identifier after procedure.\n");
				exit(1);
			}

			// looks for an identifier in the symbol table to ensure there are no duplicates
			char *tempStr = malloc(sizeof(char) * 500);
			strcpy(tempStr, getToken(index, lexemeList)->str);
			int tempIndex = contains(table, tempStr, 0, 0);
			// duplicate identifier error
			if (tempIndex != -1 && table[tempIndex].mark == 0 && table[tempIndex].level == lexlevel)
			{
				error = 1;
				printf("Error: Duplicate identifier.\n");
				exit(1);
			}

			// adds the procedure to the symbol table with kind 3 and increments size
			table[size] = add(table, 3, tempStr, 0, lexlevel - 1, 0, 0);
			size++;

			// makes sure each identifier is followed by a semicolon
			currToken = getToken(index, lexemeList);
			if (currToken->num != semicolonsym)
			{
				error = 1;
				printf("Error: Semicolon or comma missing.\n");
				exit(1);
			}

			currToken = getToken(index, lexemeList);

			block(index, table, lexemeList, lexlevel);

			// semicolon missing error
			if (currToken->num != semicolonsym)
			{
				error = 1;
				printf("Error: Semicolon or comma missing.\n");
				exit(1);
			}

			currToken = getToken(index, lexemeList);

			// keeps track of the number of procedures
			numProcedures++;
		} while(currToken->num == procsym);
	}

	// returns the number of procedures
	return numProcedures;
}

// function used for conditional statements
void condition(int *index, symbol *table, char *lexemeList, int lexlevel)
{
	if (currToken->num == oddsym)
	{
		currToken = getToken(index, lexemeList);
		expression(index, table, lexemeList, lexlevel);
	}
	else
	{
		expression(index, table, lexemeList, lexlevel);
		// throws an error if an invalid comparison symbol is given
		if (!(currToken->num == eqsym || currToken->num == neqsym || currToken->num == lessym || currToken->num == leqsym || currToken->num == gtrsym || currToken->num == geqsym))
		{
			error = 1;
			printf("Error: Incorrect symbol in expression.\n");
			exit(1);
		}

		currToken = getToken(index, lexemeList);
		expression(index, table, lexemeList, lexlevel);
	}
	return;
}

// function used to calculate factors
void factor(int *index, symbol *table, char *lexemeList, int lexlevel)
{
	if (currToken->num == identsym)
	{
		// checks if our identifier is in the symbol table
		char *tempStr = malloc(sizeof(char) * 500);
		strcpy(tempStr, getToken(index, lexemeList)->str);
		int tempIndex = contains(table, tempStr, 1, 2);

		// if the identifier is not in the symbol table, throws an error
		if (tempIndex == -1)
		{
			error = 1;
			printf("Error: Undeclared or marked identifier.\n");
			exit(1);
		}

		currToken = getToken(index, lexemeList);
	}
	// checks if token is a number
	else if (currToken->num == numbersym)
	{
		currToken = getToken(index, lexemeList);
		currToken = getToken(index, lexemeList);
	}
	// checks if token is a left parenthesis
	else if (currToken->num == lparentsym)
	{
		currToken = getToken(index, lexemeList);
		expression(index, table, lexemeList, lexlevel);
		// throws an error if statement is not closed with a right parenthesis
		if (currToken->num != rparentsym)
		{
			error = 1;
			printf("Error: Right parenthesis missing.\n");
			exit(1);
		}
		currToken = getToken(index, lexemeList);
	}
	// if none of these conditions are met, throws an invalid expression error
	else
	{
		error = 1;
		printf("Error: Invalid expression.\n");
		exit(1);
	}
}

// function for terms
void term(int *index, symbol *table, char *lexemeList, int lexlevel)
{
	factor(index, table, lexemeList, lexlevel);

	// loops for multiplication and division
	while(currToken->num == multsym || currToken->num == slashsym)
	{
		currToken = getToken(index, lexemeList);
		factor(index, table, lexemeList, lexlevel);
	}
}

// function for expressions
void expression(int *index, symbol *table, char *lexemeList, int lexlevel)
{
	// checks if the current index in the lexeme list is a + or - symbol
	if (currToken->num == plussym || currToken->num == minussym)
	{
		currToken = getToken(index, lexemeList);
	}
	term(index, table, lexemeList, lexlevel);

	// loops for addition and subtraction
	while(currToken->num == plussym || currToken->num == minussym)
	{
		currToken = getToken(index, lexemeList);
		term(index, table, lexemeList, lexlevel);
	}
}

// function for statements
void statement(int *index, symbol *table, char *lexemeList, int lexlevel)
{
	if (error)
		return;
	// checks for error in case of becomes symbol with no identifier
	if (currToken->num == becomessym)
	{
		error = 1;
		printf("Error: Expected identifier before :=.\n");
		exit(1);
	}
	// checks if current token is an identifier
	if (currToken->num == identsym)
	{
		// searches for the current identifier in the symbol table
		char *tempStr = malloc(sizeof(char) * 500);
		strcpy(tempStr, getToken(index, lexemeList)->str);
		int tempIndex = contains(table, tempStr, 1, 2);

		// if the identifier is not found, throws an error
		if (tempIndex == -1)
		{
			error = 1;
			printf("Error: Undeclared or marked identifier.\n");
			exit(1);
		}

		// if identifier is not followed by a becomes symbol, throws an error
		currToken = getToken(index, lexemeList);
		if (currToken->num != becomessym)
		{
			error = 1;
			printf("Error: Expected := after var.\n");
			exit(1);
		}

		currToken = getToken(index, lexemeList);

		expression(index, table, lexemeList, lexlevel);
		return;
	}
	// checks if current token is call
	if (currToken->num == callsym)
	{
		currToken = getToken(index, lexemeList);

		// searches for the current identifier in the symbol table
		char *tempStr = malloc(sizeof(char) * 500);
		strcpy(tempStr, getToken(index, lexemeList)->str);
		int tempIndex = contains(table, tempStr, 1, 3);

		// if the identifier is not found, throws an error
		if (tempIndex == -1)
		{
			error = 1;
			printf("Error: Undeclared or marked identifier.\n");
			exit(1);
		}

		currToken = getToken(index, lexemeList);

		return;
	}
	// checks if current token is begin
	if (currToken->num == beginsym)
	{
		currToken = getToken(index, lexemeList);
		statement(index, table, lexemeList, lexlevel);
		// loops while our current statements end in semicolons
		while (currToken->num == semicolonsym || thenFlag)
		{
			if (error)
				return;

			if (!thenFlag)
				currToken = getToken(index, lexemeList);
			thenFlag = 0;
			statement(index, table, lexemeList, lexlevel);
		}

		// if missing end token, throws an error
		if (currToken->num != endsym)
		{
			error = 1;
			printf("Error: Expected end.\n");
			exit(1);
		}

		currToken = getToken(index, lexemeList);
		return;
	}
	// checks if current token is if
	if (currToken->num == ifsym)
	{
		thenFlag = 1;
		currToken = getToken(index, lexemeList);
		condition(index, table, lexemeList, lexlevel);
		// throws an error flag if there is no then token after if statement
		if (currToken->num != thensym)
		{
			error = 1;
			printf("Error: then expected after if statement.\n");
			exit(1);
		}

		currToken = getToken(index, lexemeList);
		statement(index, table, lexemeList, lexlevel);

		// checks if current token is else
		if (currToken->num == elsesym)
		{
			currToken = getToken(index, lexemeList);
			statement(index, table, lexemeList, lexlevel);
		}
		return;
	}
	// checks if current token is while
	if (currToken->num == whilesym)
	{
		currToken = getToken(index, lexemeList);
		condition(index, table, lexemeList, lexlevel);
		// throws an error if there is no do token after while statement
		if (currToken->num != dosym)
		{
			error = 1;
			printf("Error: do expected after while.\n");
			exit(1);
		}
		currToken = getToken(index, lexemeList);
		statement(index, table, lexemeList, lexlevel);
		return;
	}
	// checks if current token is read
	if (currToken->num == readsym)
	{
		currToken = getToken(index, lexemeList);
		// throws an error if there is no identifier after read
		if (currToken->num != identsym)
		{
			error = 1;
			printf("Error: Identifier expected after read.\n");
			exit(1);
		}

		// checks to make sure current identifier is in the symbol table
		char *tempStr = malloc(sizeof(char) * 500);
		strcpy(tempStr, getToken(index, lexemeList)->str);
		int tempIndex = contains(table, tempStr, 1, 2);

		// if not, throws an error
		if (tempIndex == -1)
		{
			error = 1;
			printf("Error: Undeclared or marked identifier.\n");
			exit(1);
		}

		currToken = getToken(index, lexemeList);
		return;
	}
	// checks if current token is write
	if (currToken->num == writesym)
	{
		currToken = getToken(index, lexemeList);
		// calls expression since we can now deal with expressions in write
		expression(index, table, lexemeList, lexlevel);
		return;
	}

	return;
}

// function for block
void block(int *index, symbol *table, char *lexemeList, int lexlevel)
{
	// keeps track of the number of symbols found through constDeclaration, varDeclaration,
	// and procedureDeclaration
	int numSymbols = 0;

	// checks if const or var symbol
	if (currToken->num == constsym && !error)
		numSymbols += constDeclaration(index, table, lexemeList, lexlevel);
	if (currToken->num == varsym && !error)
		numSymbols += varDeclaration(index, table, lexemeList, lexlevel);

	numSymbols += procedureDeclaration(index, table, lexemeList, lexlevel + 1);

	if (!error)
		statement(index, table, lexemeList, lexlevel);

	// marks all symbols in the symbol table
	int tempIndex = size - 1;
	int marked = 0;
	while (marked != numSymbols)
	{
		if (table[tempIndex].mark == 0)
		{
			table[tempIndex].mark = 1;
			marked++;
		}
		tempIndex--;
	}
}

// function for the program
void program(int *index, symbol *table, char *lexemeList)
{
	// adds main procedure to symbol table then increments size
	table[size] = add(table, 3, "main", 0, 0, 0, 0);
	size++;

	currToken = getToken(index, lexemeList);

	block(index, table, lexemeList, 0);
	// if program doesn't end with a period, throws an error
	if (currToken->num != periodsym)
	{
		error = 1;
		printf("Error: Period expected.\n");
		exit(1);
	}
	return;
}

// function that returns the next token in the lexeme list
token *getToken(int *index, char *lexemeList)
{
	int tokenIndex = 0, i;
	token *newToken = calloc(1, sizeof(token));
	newToken->str = calloc(500, sizeof(char));
	char tempChar[20];
	int tempInt[20];

	// if next token is some number, converts it to an integer from char
	if (isdigit(lexemeList[*index]))
	{
		while (lexemeList[*index] != ' ')
		{
			int temp = lexemeList[*index] - '0';
			tempInt[tokenIndex] = temp;
			(*index)++;
			tokenIndex++;
		}

		for (i = 0; i < tokenIndex; i++)
		{
			newToken->num = 10 * newToken->num + tempInt[i];
		}
	}
	else
	{
		// stores identifiers in token struct
		newToken->num = -1;
		int strIndex = 0;
		while (lexemeList[*index] != ' ')
		{
			newToken->str[strIndex] = lexemeList[*index];
			strIndex++;
			tempChar[tokenIndex] = lexemeList[*index];
			(*index)++;
		}
	}

	(*index)++;

	return newToken;
}

// function to parse through the lexeme list to check for syntactical errors
symbol *parse(char *lexemeList, int lexError)
{
	int index = 0, *ptr;
	symbol *table = malloc(sizeof(symbol) * MAX_SYMBOL_TABLE_SIZE);

	ptr = &index;

	printf("\n");

	// checks for errors thrown by the lexical analyzer
	if (lexError > 0)
	{
		if (lexError == 1)
			printf("\nError: Invalid identifier.\n");
		else if (lexError == 2)
			printf("\nError: Number too large.\n");
		else if (lexError == 3)
			printf("\nError: Name too long.\n");
		else
			printf("\nError: Invalid symbols.\n");
		return NULL;
	}
	else
	{
		program(ptr, table, lexemeList);
	}

	if (error)
		return NULL;

	printf("No errors, program is syntactically correct.\n");

	return table;
}
