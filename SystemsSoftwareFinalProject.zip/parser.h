// Joshua Tobler, Samuel Briceno
// COP 3402, Fall 2020

#ifndef __PARSER_H
#define __PARSER_H

#include "lexeme.h"

typedef struct symbol
{
	int kind;
	char name[12];
	int val;
	int level;
	int addr;
	int mark;
} symbol;

typedef struct token
{
	int num;
	char *str;
} token;

symbol *parse(char *lexemeList, int lexError);

#endif
