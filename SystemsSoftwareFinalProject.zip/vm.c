// Joshua Tobler, Samuel Briceno
// COP 3402, Fall 2020

#include <stdio.h>

// given global variables
#define MAX_STACK_HEIGHT 1000

// global variables for OP, R, L, and M indices in array for clarity
#define OP 0
#define R 1
#define L 2
#define M 3

// base function taken from project PDF
int base(int l, int base, int *stack)
{
	int b1;
	b1 = base;

	while (l > 0)
	{
		b1 = stack[b1];
		l--;
	}

	return b1;
}

// function that prints out the terminal
void printValues(int currPC, int oldPC, int BP, int SP, int **code, int *reg, int *stack, char *str, int *incCounter)
{
	int i, j = 0, k = 0;
	int stackHeight = MAX_STACK_HEIGHT - SP;
	if (currPC == 0)
	{
		// prints out the initial state for the program
		printf("\t\t\t\t\tpc\tbp\tsp\n");
		printf("Initial values\t\t\t\t%d\t%d\t%d\n", currPC, BP, SP);
		printf("Registers:");
		for (i = 0; i < 8; i++)
		{
			printf(" %d", reg[i]);
		}
		printf("\nStack:\n\n");
	}
	else
	{
		// prints out the state of the program after the current instruction
		printf("%d %s %d %d %d\t\t\t\t%d\t%d\t%d\n", oldPC, str, code[oldPC][R], code[oldPC][L], code[oldPC][M], currPC, BP, SP);
		// prints out register file values
		printf("Registers:");
		for (i = 0; i < 8; i++)
		{
			printf(" %d", reg[i]);
		}
		printf("\n");
		// prints out all elements on the stack
		printf("Stack:");
		// if we have elements currently on the stack
		if (stackHeight > 0)
		{
			// while there is an activation record
			while (incCounter[j] != 0)
			{
				// loop through each value in the activation record
				for (i = 0; i < incCounter[j]; i++)
				{
					printf(" %d", stack[999 - (i + k)]);
				}
				// if there is an AR after the current one, prints "|"
				if (incCounter[j + 1] != 0)
				{
					printf(" |");
					k += incCounter[j];
				}
				j++;
			}
		}
		printf("\n\n");
	}
}

// pc bp sp reg stack
void virtualMachine(int **code, int flag)
{
	// stack is initialized to zero for the full height of the stack (1000)
	int stack[MAX_STACK_HEIGHT] = {0};
	// register file initialized to 0
	int RF[8] = {0};

	// variable used to keep track of activation records
	int incCounter[MAX_STACK_HEIGHT] = {0};
	int incCounterIndex = 0;

	// halt condition initialized to 1
	int halt = 1;

	// initial values for SP, BP, PC, IR
	int SP = MAX_STACK_HEIGHT;
	int BP = SP - 1;
	int PC = 0;
	int IR = 0;

	// prints out initial state before the fetch/execute cycle
	if (flag == 1)
	{
		printf("\n");
		printValues(PC, 0, BP, SP, code, RF, stack, "", incCounter);
	}

	while (halt == 1)
	{
		int oldPC = PC;
		// fetch cycle
		IR = code[PC][0];
		PC++;

		// execute cycle
		switch(IR)
		{
			case 1:
				// load literal to stack
				RF[code[PC - 1][R]] = code[PC-1][M];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "LIT", incCounter);
				break;
			case 2:
				// return instruction
				SP = BP + 1;
				BP = stack[SP - 2];
				PC = stack[SP - 3];
				// update incCounter/index variables to indicate deletion of top AR
				incCounterIndex--;
				incCounter[incCounterIndex] = 0;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "RTN", incCounter);
				break;
			case 3:
				// load instruction
				RF[code[PC - 1][R]] = stack[base(code[PC - 1][L], BP, stack) - code[PC - 1][M]];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "LOD", incCounter);
				break;
			case 4:
				// store instruction
				stack[base(code[PC - 1][L], BP, stack) - code[PC - 1][M]] = RF[code[PC - 1][R]];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "STO", incCounter);
				break;
			case 5:
				// call instruction
				stack[SP - 1] = base(code[PC - 1][L], BP, stack);
				stack[SP - 2] = BP;
				stack[SP - 3] = PC;
				BP = SP - 1;
				PC = code[PC - 1][M];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "CAL", incCounter);
				break;
			case 6:
				// increment instruction
				SP -= code[PC - 1][M];
				// update incCounter/index variables to indicate new AR
				incCounter[incCounterIndex] = code[PC - 1][M];
				incCounterIndex++;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "INC", incCounter);
				break;
			case 7:
				// jumps to instruction M
				PC = code[PC - 1][M];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "JMP", incCounter);
				break;
			case 8:
				// jump to M if RF[R] is 0
				if (RF[code[PC - 1][R]] == 0)
					PC = code[PC - 1][M];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "JPC", incCounter);
				break;
			case 9:
				// SYS instruction
				// write RF[R] to the terminal
				if (code[PC - 1][M] == 1)
					printf("Register %d: %d\n\n", code[PC - 1][R], RF[code[PC - 1][R]]);
				else if (code[PC - 1][M] == 2)
				{
					// scan input and store on register
					printf("Please enter an integer: ");
					scanf("%d", &RF[code[PC - 1][R]]);
				}
				// set halt flag to 0
				else if (code[PC - 1][M] == 3)
					halt = 0;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "SYS", incCounter);
				break;
			case 10:
				// negate arithmetic instruction
				RF[code[PC - 1][R]] *= -1;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "NEG", incCounter);
				break;
			case 11:
				// addition arithmetic instruction
				RF[code[PC - 1][R]] = RF[code[PC - 1][L]] + RF[code[PC - 1][M]];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "ADD", incCounter);
				break;
			case 12:
				// subtraction arithmetic instruction
				RF[code[PC - 1][R]] = RF[code[PC - 1][L]] - RF[code[PC - 1][M]];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "SUB", incCounter);
				break;
			case 13:
				// multiplication arithmetic instruction
				RF[code[PC - 1][R]] = RF[code[PC - 1][L]] * RF[code[PC - 1][M]];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "MUL", incCounter);
				break;
			case 14:
				// division arithmetic instruction
				RF[code[PC - 1][R]] = RF[code[PC - 1][L]] / RF[code[PC - 1][M]];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "DIV", incCounter);
				break;
			case 15:
				// checks if RF[R] is odd
				RF[code[PC - 1][R]] %= 2;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "ODD", incCounter);
				break;
			case 16:
				// mod arithmetic instruction
				RF[code[PC - 1][R]] = RF[code[PC - 1][L]] % RF[code[PC - 1][M]];
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "MOD", incCounter);
				break;
			case 17:
				// checks equality
				if (RF[code[PC - 1][L]] == RF[code[PC - 1][M]])
					RF[code[PC - 1][R]] = 1;
				else
					RF[code[PC - 1][R]] = 0;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "EQL", incCounter);
				break;
			case 18:
				// checks if not equal to
				if (RF[code[PC - 1][L]] != RF[code[PC - 1][M]])
					RF[code[PC - 1][R]] = 1;
				else
					RF[code[PC - 1][R]] = 0;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "NEQ", incCounter);
				break;
			case 19:
				// checks less than
				if (RF[code[PC - 1][L]] < RF[code[PC - 1][M]])
					RF[code[PC - 1][R]] = 1;
				else
					RF[code[PC - 1][R]] = 0;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "LSS", incCounter);
				break;
			case 20:
				// checks less than or equal to
				if (RF[code[PC - 1][L]] <= RF[code[PC - 1][M]])
					RF[code[PC - 1][R]] = 1;
				else
					RF[code[PC - 1][R]] = 0;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "LEQ", incCounter);
				break;
			case 21:
			// checks greater than
				if (RF[code[PC - 1][L]] > RF[code[PC - 1][M]])
					RF[code[PC - 1][R]] = 1;
				else
					RF[code[PC - 1][R]] = 0;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "GTR", incCounter);
				break;
			case 22:
				// checks greater than or equal to
				if (RF[code[PC - 1][L]] >= RF[code[PC - 1][M]])
					RF[code[PC - 1][R]] = 1;
				else
					RF[code[PC - 1][R]] = 0;
				// send current state to print function to print onto the terminal
				if (flag == 1)
					printValues(PC, oldPC, BP, SP, code, RF, stack, "GEQ", incCounter);
				break;
		}
	}
}
