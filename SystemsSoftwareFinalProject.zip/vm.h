// Joshua Tobler, Samuel Briceno
// COP 3402, Fall 2020

#ifndef __VM_H
#define __VM_H

#include "codegen.h"

void virtualMachine(int **code, int flag);

#endif
